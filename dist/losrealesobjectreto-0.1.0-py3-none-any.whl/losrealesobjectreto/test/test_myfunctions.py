def detect_objects_in_video(video_path, output_path):
    return True
def get_frame_info(frame):
    return True